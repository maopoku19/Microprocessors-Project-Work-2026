from flask import Flask, jsonify, render_template
from flask_cors import CORS
import csv, os, json

app = Flask(__name__)
CORS(app)

DATA_FILE    = r'C:\Users\HP\Documents\VitalSigns_Project\data\vitals_log.csv'
SUMMARY_FILE = r'C:\Users\HP\Documents\VitalSigns_Project\data\evaluation_summary.json'

def read_vitals():
    readings, anomalies = [], []
    try:
        with open(DATA_FILE, 'r') as f:
            reader = csv.DictReader(f)
            for row in reader:
                readings.append(row)
                if row.get('status') in ['WARNING', 'CRITICAL']:
                    anomalies.append(row)
    except FileNotFoundError:
        pass
    return readings, anomalies

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/vitals')
def get_vitals():
    readings, anomalies = read_vitals()
    latest = readings[-1] if readings else {}
    return jsonify({
        'latest': latest,
        'history': readings[-30:],
        'anomalies': anomalies[-10:]
    })

@app.route('/api/current_patient')
def get_current_patient():
    patient_path = r'C:\Users\HP\Documents\VitalSigns_Project\data\current_patient.json'
    try:
        with open(patient_path, 'r') as f:
            return jsonify(json.load(f))
    except FileNotFoundError:
        return jsonify({'patient_id': '--', 'condition': 'No patient selected'})

@app.route('/api/validation')
def get_validation():
    try:
        with open(SUMMARY_FILE, 'r') as f:
            return jsonify(json.load(f))
    except FileNotFoundError:
        return jsonify({'error': 'No validation data found'}), 404
    
if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
