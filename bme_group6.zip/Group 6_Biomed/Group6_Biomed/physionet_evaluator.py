import pandas as pd
import numpy as np
import json
import os
from datetime import datetime

BASE_DIR = r'C:\Users\HP\Documents\VitalSigns_Project'
INPUT_CSV = os.path.join(BASE_DIR,'data','physionet_patients.csv')
RESULTS_CSV = os.path.join(BASE_DIR,'data','evaluation_results.csv')
SUMMARY_JSON = os.path.join(BASE_DIR,'data','evaluation_summary.json')

WARN_THRESH = 2.0
CRITICAL_THRESH = 3.5

GLOBAL_BASELINE = {
    'heart_rate':{'mean':72,'std':10},
    'temperature':{'mean':36.8,'std':0.6},
    'spo2':{'mean':98.5,'std':1.5},
}

df = pd.read_csv(INPUT_CSV)
print(f'Loaded {len(df)} readings from {df["patient_id"].nunique()} patients')

def is_normal(row, b):
    for v in ['heart_rate','temperature','spo2']:
        if abs(row[v] - b[v]['mean']) / b[v]['std'] >= 2.0:
            return False
    return True

def detect(group):
    results = []
    baseline = None
    for i, row in enumerate(group.itertuples()):
        if i < 20:
            results.append(('NORMAL','building baseline'))
            continue
        if baseline is None:
            w = group.iloc[i-20:i]
            nc = sum(1 for _,r in w.iterrows() if is_normal(r, GLOBAL_BASELINE))
            if nc >= 14:
                baseline = {v:{'mean':w[v].mean(),'std':max(w[v].std(),s)} for v,s in [('heart_rate',3.0),('temperature',0.2),('spo2',0.5)]}
            else:
                baseline = GLOBAL_BASELINE
        status = 'NORMAL'
        details = []
        for v in ['heart_rate','temperature','spo2']:
            z = abs(getattr(row,v) - baseline[v]['mean']) / baseline[v]['std']
            if z >= CRITICAL_THRESH:
                details.append(f'{v} CRITICAL')
                status = 'CRITICAL'
            elif z >= WARN_THRESH:
                details.append(f'{v} WARNING')
                if status != 'CRITICAL': status = 'WARNING'
        results.append((status,'; '.join(details)))
    return results

all_results = []
for pid, group in df.groupby('patient_id'):
    group = group.reset_index(drop=True)
    for i,(status,detail) in enumerate(detect(group)):
        all_results.append({'patient_id':pid,'idx':i,'detected_status':status,'detected_detail':detail})

rdf = pd.DataFrame(all_results)
df = df.reset_index(drop=True)
df['detected_status'] = rdf['detected_status'].values
df['detected_detail'] = rdf['detected_detail'].values
df['actual_anomaly'] = (df['ground_truth'] != 'NORMAL').astype(int)
df['detected_anomaly'] = (df['detected_status'].isin(['WARNING','CRITICAL'])).astype(int)
edf = df[df['detected_status'] != 'building baseline'].copy()

TP = ((edf['actual_anomaly']==1)&(edf['detected_anomaly']==1)).sum()
TN = ((edf['actual_anomaly']==0)&(edf['detected_anomaly']==0)).sum()
FP = ((edf['actual_anomaly']==0)&(edf['detected_anomaly']==1)).sum()
FN = ((edf['actual_anomaly']==1)&(edf['detected_anomaly']==0)).sum()

accuracy    = round((TP+TN)/(TP+TN+FP+FN)*100,2)
sensitivity = round(TP/(TP+FN)*100,2) if (TP+FN)>0 else 0
specificity = round(TN/(TN+FP)*100,2) if (TN+FP)>0 else 0
precision   = round(TP/(TP+FP)*100,2) if (TP+FP)>0 else 0
f1          = round(2*(precision*sensitivity)/(precision+sensitivity),2) if (precision+sensitivity)>0 else 0

per_patient = []
for pid,group in edf.groupby('patient_id'):
    cond = group['condition'].iloc[0]
    tp = ((group['actual_anomaly']==1)&(group['detected_anomaly']==1)).sum()
    tn = ((group['actual_anomaly']==0)&(group['detected_anomaly']==0)).sum()
    fp = ((group['actual_anomaly']==0)&(group['detected_anomaly']==1)).sum()
    fn = ((group['actual_anomaly']==1)&(group['detected_anomaly']==0)).sum()
    acc  = round((tp+tn)/(tp+tn+fp+fn)*100,1) if (tp+tn+fp+fn)>0 else 0
    sens = round(tp/(tp+fn)*100,1) if (tp+fn)>0 else 0
    per_patient.append({'patient_id':pid,'condition':cond,'TP':int(tp),'TN':int(tn),'FP':int(fp),'FN':int(fn),'accuracy':acc,'sensitivity':sens})

df.to_csv(RESULTS_CSV, index=False)
summary = {'generated_at':datetime.now().strftime('%Y-%m-%d %H:%M:%S'),'total_readings':int(len(edf)),'total_patients':int(edf["patient_id"].nunique()),'confusion_matrix':{'TP':int(TP),'TN':int(TN),'FP':int(FP),'FN':int(FN)},'metrics':{'accuracy':accuracy,'sensitivity':sensitivity,'specificity':specificity,'precision':precision,'f1_score':f1},'per_patient':per_patient}
with open(SUMMARY_JSON,'w') as f: json.dump(summary,f,indent=2)

print(f'\n=== RESULTS (Hybrid Baseline) ===')
print(f'TP={TP}  TN={TN}  FP={FP}  FN={FN}')
print(f'Accuracy:    {accuracy}%')
print(f'Sensitivity: {sensitivity}%')
print(f'Specificity: {specificity}%')
print(f'Precision:   {precision}%')
print(f'F1 Score:    {f1}%')
print(f'\nPer-patient breakdown:')
for p in per_patient:
    print(f'  {p["patient_id"]} {p["condition"]:<22} Acc={p["accuracy"]}%  Sens={p["sensitivity"]}%')
print(f'Saved to {RESULTS_CSV}')
print(f'Saved to {SUMMARY_JSON}')
