"""
====================================================
Smart Wearable Vital Signs Monitoring System
Python Data Pipeline — v1.0
====================================================
Layers covered:
  1. Synthetic data generator (mimics Arduino serial output)
  2. Data reader & parser
  3. Patient baseline profiler
  4. Anomaly detection (Z-score)
  5. CSV data logger
====================================================
"""

import numpy as np
import pandas as pd
import time
import os
from datetime import datetime


# ────────────────────────────────────────────────
# CONFIGURATION
# ────────────────────────────────────────────────

BASELINE_SAMPLES = 20        # Number of readings to build the baseline
LOG_FILE = r"C:\Users\HP\Downloads\vitals_log.csv" # Output CSV file name
READING_INTERVAL = 1         # Seconds between each reading
TOTAL_READINGS = 50          # Total readings to simulate

# Normal vital sign ranges (for synthetic data generation)
NORMAL_RANGES = {
    "heart_rate": (60, 100),       # BPM
    "temperature": (36.1, 37.5),   # Celsius
    "spo2": (95, 100),             # Percentage
}

# Z-score threshold — anything beyond this is flagged as anomaly
Z_THRESHOLD = 2.0


# ────────────────────────────────────────────────
# STEP 1: SYNTHETIC ARDUINO SERIAL DATA GENERATOR
# ────────────────────────────────────────────────

def generate_reading(reading_index):
    """
    Simulates a serial data packet from Arduino.
    Injects anomalies at specific points to test detection.
    Format mimics: HR:75,TEMP:36.8,SPO2:98
    """

    # Inject anomaly scenarios at specific readings
    if reading_index == 30:
        # Simulate tachycardia (high heart rate)
        heart_rate = round(np.random.uniform(130, 150), 1)
    elif reading_index == 35:
        # Simulate fever
        temperature = round(np.random.uniform(38.5, 39.5), 1)
        heart_rate = round(np.random.uniform(60, 100), 1)
        spo2 = round(np.random.uniform(95, 100), 1)
        return f"HR:{heart_rate},TEMP:{temperature},SPO2:{spo2}"
    elif reading_index == 40:
        # Simulate low SpO2 (hypoxia)
        spo2 = round(np.random.uniform(88, 92), 1)
        heart_rate = round(np.random.uniform(60, 100), 1)
        temperature = round(np.random.uniform(36.1, 37.5), 1)
        return f"HR:{heart_rate},TEMP:{temperature},SPO2:{spo2}"
    else:
        heart_rate = round(np.random.uniform(*NORMAL_RANGES["heart_rate"]), 1)

    temperature = round(np.random.uniform(*NORMAL_RANGES["temperature"]), 1)
    spo2 = round(np.random.uniform(*NORMAL_RANGES["spo2"]), 1)

    return f"HR:{heart_rate},TEMP:{temperature},SPO2:{spo2}"


# ────────────────────────────────────────────────
# STEP 2: DATA PARSER
# ────────────────────────────────────────────────

def parse_reading(raw_data):
    """
    Parses the raw serial string into a dictionary.
    Input:  "HR:75,TEMP:36.8,SPO2:98"
    Output: {"heart_rate": 75.0, "temperature": 36.8, "spo2": 98.0}
    """
    try:
        parts = raw_data.strip().split(",")
        parsed = {}
        for part in parts:
            key, value = part.split(":")
            key = key.strip()
            value = float(value.strip())

            # Map short keys to full names
            if key == "HR":
                parsed["heart_rate"] = value
            elif key == "TEMP":
                parsed["temperature"] = value
            elif key == "SPO2":
                parsed["spo2"] = value

        return parsed
    except Exception as e:
        print(f"  [PARSE ERROR] Could not parse: {raw_data} — {e}")
        return None


# ────────────────────────────────────────────────
# STEP 3: BASELINE PROFILER
# ────────────────────────────────────────────────

class BaselineProfiler:
    """
    Collects initial readings to establish the patient's
    personal normal vital sign baseline (mean + std dev).
    """

    def __init__(self, sample_size):
        self.sample_size = sample_size
        self.samples = []
        self.baseline = None

    def add_sample(self, reading):
        self.samples.append(reading)

    def is_ready(self):
        return len(self.samples) >= self.sample_size

    def build_baseline(self):
        df = pd.DataFrame(self.samples)
        self.baseline = {
            "mean": df.mean().to_dict(),
            "std": df.std().to_dict()
        }
        print("\n  ✅ Baseline established from first", self.sample_size, "readings:")
        print(f"     Heart Rate  — Mean: {self.baseline['mean']['heart_rate']:.1f} BPM  | Std: {self.baseline['std']['heart_rate']:.2f}")
        print(f"     Temperature — Mean: {self.baseline['mean']['temperature']:.1f} °C  | Std: {self.baseline['std']['temperature']:.2f}")
        print(f"     SpO2        — Mean: {self.baseline['mean']['spo2']:.1f} %    | Std: {self.baseline['std']['spo2']:.2f}")
        print()
        return self.baseline


# ────────────────────────────────────────────────
# STEP 4: ANOMALY DETECTOR
# ────────────────────────────────────────────────

class AnomalyDetector:
    """
    Uses Z-score method to detect anomalies.
    Z = (value - mean) / std
    If |Z| > threshold, the reading is flagged.
    """

    def __init__(self, baseline, threshold=Z_THRESHOLD):
        self.baseline = baseline
        self.threshold = threshold

    def check(self, reading):
        anomalies = []
        status = "NORMAL"

        for vital, value in reading.items():
            mean = self.baseline["mean"][vital]
            std = self.baseline["std"][vital]

            if std == 0:
                continue

            z_score = abs((value - mean) / std)

            if z_score > self.threshold:
                anomalies.append({
                    "vital": vital,
                    "value": value,
                    "z_score": round(z_score, 2)
                })

        if anomalies:
            # Determine severity
            max_z = max(a["z_score"] for a in anomalies)
            status = "CRITICAL" if max_z > 3.5 else "WARNING"

        return status, anomalies


# ────────────────────────────────────────────────
# STEP 5: CSV DATA LOGGER
# ────────────────────────────────────────────────

class DataLogger:
    """
    Logs all readings with timestamps, status, and anomaly details to CSV.
    """

    def __init__(self, filename):
        self.filename = filename
        self.records = []

    def log(self, reading, status, anomalies):
        record = {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "heart_rate": reading.get("heart_rate"),
            "temperature": reading.get("temperature"),
            "spo2": reading.get("spo2"),
            "status": status,
            "anomaly_details": str(anomalies) if anomalies else "None"
        }
        self.records.append(record)

    def save(self):
        df = pd.DataFrame(self.records)
        df.to_csv(self.filename, index=False)
        print(f"\n  💾 Data saved to: {os.path.abspath(self.filename)}")


# ────────────────────────────────────────────────
# MAIN PIPELINE
# ────────────────────────────────────────────────

def run_pipeline():
    print("=" * 55)
    print("  Smart Vital Signs Monitoring Pipeline — RUNNING")
    print("=" * 55)
    print(f"  Baseline samples : {BASELINE_SAMPLES}")
    print(f"  Total readings   : {TOTAL_READINGS}")
    print(f"  Z-score threshold: {Z_THRESHOLD}")
    print(f"  Log file         : {LOG_FILE}")
    print("=" * 55)
    print("\n  📡 Starting data stream...\n")

    profiler = BaselineProfiler(BASELINE_SAMPLES)
    logger = DataLogger(LOG_FILE)
    detector = None

    for i in range(1, TOTAL_READINGS + 1):

        # Step 1: Generate synthetic serial data
        raw = generate_reading(i)

        # Step 2: Parse the raw string
        reading = parse_reading(raw)
        if reading is None:
            continue

        # Step 3: Build baseline from first N readings
        if not profiler.is_ready():
            profiler.add_sample(reading)
            print(f"  [{i:02d}] Collecting baseline... HR:{reading['heart_rate']} | TEMP:{reading['temperature']} | SpO2:{reading['spo2']}")
            logger.log(reading, "BASELINE", [])

            if profiler.is_ready():
                baseline = profiler.build_baseline()
                detector = AnomalyDetector(baseline)
            continue

        # Step 4: Detect anomalies
        status, anomalies = detector.check(reading)

        # Step 5: Log to CSV
        logger.log(reading, status, anomalies)

        # Console output
        status_icon = {"NORMAL": "🟢", "WARNING": "🟡", "CRITICAL": "🔴"}.get(status, "⚪")
        print(f"  [{i:02d}] {status_icon} {status:<8} | HR:{reading['heart_rate']:>5} BPM | TEMP:{reading['temperature']:>5} °C | SpO2:{reading['spo2']:>5}%", end="")

        if anomalies:
            for a in anomalies:
                print(f"\n        ⚠️  ANOMALY — {a['vital'].replace('_', ' ').title()}: {a['value']} (Z-score: {a['z_score']})", end="")
        print()

        time.sleep(0.1)  # Small delay to simulate real-time (set to READING_INTERVAL for real use)

    # Save all logs
    logger.save()
    print("\n" + "=" * 55)
    print("  ✅ Pipeline complete.")
    print("=" * 55)


# ────────────────────────────────────────────────
# RUN
# ────────────────────────────────────────────────

if __name__ == "__main__":
    run_pipeline()
