"""
AnomaVital Sentinel AI — Single Patient Monitor
Drives both the Flask dashboard AND Arduino LCD simultaneously.
Simulates a real deteriorating patient scenario.
"""

import csv
import os
import time
import serial
import serial.tools.list_ports
from datetime import datetime

BASE_DIR  = r'C:\Users\HP\Documents\VitalSigns_Project'
DATA_FILE = os.path.join(BASE_DIR, 'data', 'vitals_log.csv')
CSV_HEADERS = ['timestamp','heart_rate','temperature','spo2','status','anomaly_detail']

BASELINE = {
    'heart_rate':  {'mean':72, 'std':10},
    'temperature': {'mean':36.8,'std':0.6},
    'spo2':        {'mean':98.5,'std':1.5},
}
WARN_THRESH     = 2.0
CRITICAL_THRESH = 3.5

# Patient deterioration scenario
# Each stage: (duration_seconds, hr, temp, spo2, label)
EXACT_READINGS =  [
    (72.5, 36.6, 98.7, 'NORMAL'), (71.6, 36.7, 98.7, 'NORMAL'),
    (72.5, 36.8, 98.2, 'NORMAL'), (71.2, 36.7, 98.6, 'NORMAL'),
    (73.9, 36.7, 98.5, 'NORMAL'), (73.6, 36.7, 98.5, 'NORMAL'),
    (72.0, 36.9, 98.1, 'NORMAL'), (72.6, 36.8, 98.6, 'NORMAL'),
    (72.1, 36.9, 98.5, 'NORMAL'), (72.2, 36.8, 98.3, 'NORMAL'),
    (74.9, 36.9, 98.1, 'NORMAL'), (74.5, 36.9, 98.6, 'NORMAL'),
    (73.7, 36.7, 98.7, 'NORMAL'), (73.9, 36.5, 98.7, 'NORMAL'),
    (72.2, 36.6, 98.6, 'NORMAL'), (73.1, 36.6, 98.7, 'NORMAL'),
    (71.3, 36.6, 98.7, 'NORMAL'), (72.7, 36.7, 98.5, 'NORMAL'),
    (75.2, 36.9, 98.3, 'NORMAL'), (74.3, 36.9, 98.4, 'NORMAL'),
    (75.9, 36.9, 98.3, 'NORMAL'), (75.0, 36.9, 98.4, 'NORMAL'),
    (73.9, 36.9, 98.2, 'NORMAL'), (76.6, 36.8, 98.5, 'NORMAL'),
    (89.3, 37.8, 97.4, 'NORMAL'), (87.6, 37.8, 97.0, 'NORMAL'),
    (87.9, 37.8, 97.2, 'NORMAL'), (88.0, 37.8, 97.2, 'NORMAL'),
    (88.3, 37.8, 97.0, 'NORMAL'), (89.1, 37.7, 97.4, 'NORMAL'),
    (95.0, 38.2, 96.7, 'WARNING'), (96.3, 38.1, 96.9, 'WARNING'),
    (95.9, 38.2, 96.5, 'WARNING'), (95.3, 38.2, 96.8, 'WARNING'),
    (93.2, 38.2, 96.7, 'WARNING'), (95.9, 38.3, 96.6, 'WARNING'),
    (101.6, 38.7, 95.8, 'WARNING'), (103.0, 38.7, 96.1, 'WARNING'),
    (103.9, 38.7, 96.3, 'WARNING'), (102.6, 38.7, 95.9, 'WARNING'),
    (101.7, 38.6, 96.4, 'WARNING'), (100.3, 38.7, 96.3, 'WARNING'),
    (108.6, 39.1, 95.4, 'CRITICAL'), (109.4, 39.2, 95.4, 'CRITICAL'),
    (109.5, 39.1, 95.5, 'CRITICAL'), (106.5, 39.0, 95.4, 'CRITICAL'),
    (106.4, 39.0, 95.7, 'CRITICAL'), (106.2, 39.0, 95.6, 'CRITICAL'),
    (119.9, 39.8, 93.7, 'CRITICAL'), (117.9, 39.9, 93.4, 'CRITICAL'),
    (117.3, 39.7, 93.4, 'CRITICAL'), (116.4, 39.8, 93.3, 'CRITICAL'),
    (119.1, 39.8, 93.6, 'CRITICAL'), (118.3, 39.7, 93.4, 'CRITICAL'),
    (124.0, 40.3, 92.3, 'CRITICAL'), (125.7, 40.2, 92.2, 'CRITICAL'),
    (123.2, 40.2, 92.0, 'CRITICAL'), (126.2, 40.2, 91.8, 'CRITICAL'),
    (124.5, 40.1, 92.1, 'CRITICAL'), (123.2, 40.2, 92.3, 'CRITICAL'),
    (132.9, 40.6, 91.1, 'CRITICAL'), (132.4, 40.5, 90.7, 'CRITICAL'),
    (131.7, 40.6, 90.5, 'CRITICAL'), (133.8, 40.7, 91.0, 'CRITICAL'),
    (130.8, 40.5, 90.7, 'CRITICAL'), (132.3, 40.6, 90.7, 'CRITICAL'),
    (138.0, 40.9, 89.4, 'CRITICAL'), (138.8, 41.1, 89.8, 'CRITICAL'),
    (136.2, 41.0, 89.4, 'CRITICAL'), (136.0, 40.9, 89.6, 'CRITICAL'),
    (136.0, 41.0, 89.6, 'CRITICAL'), (139.1, 40.9, 89.3, 'CRITICAL'),
    (126.3, 40.2, 90.9, 'CRITICAL'), (124.0, 40.2, 91.3, 'CRITICAL'),
    (123.9, 40.1, 91.2, 'CRITICAL'), (125.7, 40.0, 91.0, 'CRITICAL'),
    (124.6, 40.1, 90.9, 'CRITICAL'), (126.3, 40.1, 90.8, 'CRITICAL'),
    (110.4, 39.6, 92.8, 'CRITICAL'), (112.1, 39.5, 92.9, 'CRITICAL'),
    (112.9, 39.6, 93.1, 'CRITICAL'), (113.8, 39.4, 92.7, 'CRITICAL'),
    (112.9, 39.4, 93.2, 'CRITICAL'), (111.6, 39.6, 93.2, 'CRITICAL'),
    (97.7, 38.8, 95.3, 'WARNING'), (97.4, 38.7, 95.1, 'WARNING'),
    (98.3, 38.7, 95.4, 'WARNING'), (96.4, 38.7, 95.2, 'WARNING'),
    (98.6, 38.9, 95.2, 'CRITICAL'), (96.7, 38.8, 94.9, 'WARNING'),
    (86.3, 38.1, 96.7, 'WARNING'), (86.8, 38.1, 96.2, 'WARNING'),
    (87.3, 38.1, 96.3, 'WARNING'), (86.8, 38.2, 96.7, 'WARNING'),
    (86.7, 38.3, 96.7, 'WARNING'), (87.6, 38.2, 96.8, 'WARNING'),
    (78.7, 37.9, 97.3, 'NORMAL'), (81.3, 37.9, 97.5, 'NORMAL'),
    (80.1, 37.8, 97.6, 'NORMAL'), (80.0, 37.9, 97.4, 'NORMAL'),
    (80.4, 37.9, 97.5, 'NORMAL'), (81.4, 37.8, 97.5, 'NORMAL'),
    (74.4, 37.3, 97.8, 'NORMAL'), (77.2, 37.4, 97.7, 'NORMAL'),
    (75.4, 37.4, 97.8, 'NORMAL'), (74.9, 37.3, 98.2, 'NORMAL'),
    (74.0, 37.3, 97.7, 'NORMAL'), (75.8, 37.3, 97.9, 'NORMAL'),
    (71.8, 36.9, 98.5, 'NORMAL'), (74.4, 36.9, 98.5, 'NORMAL'),
    (72.2, 36.9, 98.4, 'NORMAL'), (72.4, 36.8, 98.6, 'NORMAL'),
    (72.4, 36.9, 98.2, 'NORMAL'), (71.3, 36.8, 98.6, 'NORMAL'),
    (70.8, 36.7, 98.3, 'NORMAL'), (71.7, 36.7, 98.8, 'NORMAL'),
    (70.4, 36.7, 98.5, 'NORMAL'), (70.2, 36.7, 98.3, 'NORMAL'),
    (71.4, 36.7, 98.5, 'NORMAL'), (71.3, 36.8, 98.3, 'NORMAL'),
]

def classify(hr, temp, spo2):
    status, details = 'NORMAL', []
    for name, value, key in [
        ('heart_rate', hr, 'heart_rate'),
        ('temperature', temp, 'temperature'),
        ('spo2', spo2, 'spo2')
    ]:
        z = abs(value - BASELINE[key]['mean']) / BASELINE[key]['std']
        if z >= CRITICAL_THRESH:
            details.append(f'{name}={value} CRITICAL')
            status = 'CRITICAL'
        elif z >= WARN_THRESH:
            details.append(f'{name}={value} WARNING')
            if status != 'CRITICAL': status = 'WARNING'
    return status, '; '.join(details)

def clear_csv():
    with open(DATA_FILE, 'w', newline='') as f:
        csv.DictWriter(f, fieldnames=CSV_HEADERS).writeheader()

def append_reading(hr, temp, spo2, status, detail):
    with open(DATA_FILE, 'a', newline='') as f:
        csv.DictWriter(f, fieldnames=CSV_HEADERS).writerow({
            'timestamp':      datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'heart_rate':     hr,
            'temperature':    temp,
            'spo2':           spo2,
            'status':         status,
            'anomaly_detail': detail
        })

def connect_arduino():
    try:
        ser = serial.Serial('COM5', 9600, timeout=2)
        print('  ✅ Connected to Arduino via COM5')
        return ser
    except Exception as e:
        print(f'  ⚠️  Could not connect to Arduino: {e}')
        print('  Running in dashboard-only mode...')
        return None

def send_to_arduino(ser, hr, temp, spo2, status):
    if ser:
        try:
            # Send format: HR,TEMP,SPO2,STATUS
            data = f'{hr},{temp},{spo2},{status}\n'
            ser.write(data.encode())
        except Exception as e:
            print(f'  Serial error: {e}')

def add_variation(base_hr, base_temp, base_spo2):
    import random
    hr   = round(base_hr   + random.uniform(-2, 2), 1)
    temp = round(base_temp + random.uniform(-0.1, 0.1), 1)
    spo2 = round(base_spo2 + random.uniform(-0.3, 0.3), 1)
    return hr, temp, spo2

print('\n Starting in:')
for i in [3,2,1]:
    print(f'  {i}...')
    time.sleep(1)
print(' GO!\n')

print('=' * 60)
print('  AnomaVital Sentinel AI — Patient Monitor')
print('  Sepsis Scenario — 120 readings x 3s = 6 minutes')
print('  Dashboard: http://localhost:5000')
print('=' * 60)

ser = connect_arduino()
clear_csv()

print('\n  Starting patient monitoring...\n')
print(' Syncing with LCD...')
time.sleep(2.5)
print(' SYNCED! Starting now... \n')

try:
    for hr, temp, spo2, status in EXACT_READINGS:
        _, detail = classify(hr, temp, spo2)
        append_reading(hr, temp, spo2, status, detail)
        send_to_arduino(ser, hr, temp, spo2, status)

        icon = '🟢' if status=='NORMAL' else ('🟡' if status=='WARNING' else '🔴')
        print(f'  {icon} [{datetime.now().strftime("%H:%M:%S")}] '
              f'HR={hr} | Temp={temp}°C | SpO2={spo2}% [{status}]')

        time.sleep(4.8)

    print('\n  ✅ Patient scenario complete!')
    print('  Patient recovered successfully.')

except KeyboardInterrupt:
    print('\n  Monitor stopped.')
finally:
    if ser:
        ser.close()