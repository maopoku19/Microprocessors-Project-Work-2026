import serial
import csv
import os
import time
from datetime import datetime

DATA_FILE = r'C:\Users\HP\Documents\VitalSigns_Project\data\vitals_log.csv'
CSV_HEADERS = ['timestamp','heart_rate','temperature','spo2','status','anomaly_detail']

BASELINE = {
    'heart_rate':  {'mean':72, 'std':10},
    'temperature': {'mean':36.8,'std':0.6},
    'spo2':        {'mean':98.5,'std':1.5},
}
WARN_THRESH     = 2.0
CRITICAL_THRESH = 3.5

def classify(hr, temp, spo2):
    status, details = 'NORMAL', []
    for name, value, key in [
        ('heart_rate',hr,'heart_rate'),
        ('temperature',temp,'temperature'),
        ('spo2',spo2,'spo2')
    ]:
        z = abs(value - BASELINE[key]['mean']) / BASELINE[key]['std']
        if z >= CRITICAL_THRESH:
            details.append(f'{name}={value} CRITICAL')
            status = 'CRITICAL'
        elif z >= WARN_THRESH:
            details.append(f'{name}={value} WARNING')
            if status != 'CRITICAL': status = 'WARNING'
    return status, '; '.join(details)

def clear_csv():
    with open(DATA_FILE, 'w', newline='') as f:
        csv.DictWriter(f, fieldnames=CSV_HEADERS).writeheader()

def append_reading(hr, temp, spo2, status, detail):
    with open(DATA_FILE, 'a', newline='') as f:
        csv.DictWriter(f, fieldnames=CSV_HEADERS).writerow({
            'timestamp':      datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'heart_rate':     hr,
            'temperature':    temp,
            'spo2':           spo2,
            'status':         status,
            'anomaly_detail': detail
        })

import random

PATIENT_SCENARIO = [
    (60,  72,  36.7, 98.5, 'NORMAL'),
    (60,  74,  36.8, 98.3, 'NORMAL'),
    (60,  85,  37.5, 97.8, 'WARNING'),
    (60,  92,  38.0, 97.2, 'WARNING'),
    (60,  98,  38.6, 96.8, 'WARNING'),
    (60, 105,  39.1, 96.2, 'WARNING'),
    (60, 118,  39.8, 94.5, 'CRITICAL'),
    (60, 125,  40.2, 93.1, 'CRITICAL'),
    (60, 138,  40.8, 91.5, 'CRITICAL'),
    (60, 145,  41.1, 89.8, 'CRITICAL'),
    (60, 110,  39.5, 93.0, 'WARNING'),
    (60,  95,  38.8, 95.5, 'WARNING'),
    (60,  82,  38.0, 97.0, 'WARNING'),
    (60,  75,  37.2, 98.0, 'NORMAL'),
    (60,  72,  36.8, 98.5, 'NORMAL'),
]

def connect_arduino():
    try:
        ser = serial.Serial('COM5', 9600, timeout=2)
        print('  ✅ Connected to Arduino LCD via COM5')
        return ser
    except Exception as e:
        print(f'  ⚠️  Arduino not connected: {e}')
        print('  Running in dashboard-only mode...')
        return None

def send_to_lcd(ser, hr, temp, spo2, status):
    if ser:
        try:
            data = f'{hr},{temp},{spo2},{status}\n'
            ser.write(data.encode())
        except Exception as e:
            print(f'  Serial error: {e}')

print('=' * 60)
print('  AnomaVital Sentinel AI — Patient Monitor')
print('  Patient: Single deterioration scenario')
print('  Dashboard: http://localhost:5000')
print('=' * 60)

ser = connect_arduino()
clear_csv()

print('\n  Starting patient monitoring...\n')

try:
    for duration, base_hr, base_temp, base_spo2, stage in PATIENT_SCENARIO:
        elapsed = 0
        while elapsed < duration:
            hr   = round(base_hr   + random.uniform(-2, 2), 1)
            temp = round(base_temp + random.uniform(-0.1, 0.1), 1)
            spo2 = round(base_spo2 + random.uniform(-0.3, 0.3), 1)

            status, detail = classify(hr, temp, spo2)
            append_reading(hr, temp, spo2, status, detail)
            send_to_lcd(ser, hr, temp, spo2, status)

            icon = '🟢' if status=='NORMAL' else ('🟡' if status=='WARNING' else '🔴')
            print(f'  {icon} [{datetime.now().strftime("%H:%M:%S")}] '
                  f'HR={hr} | Temp={temp}°C | SpO2={spo2}% [{status}]')

            time.sleep(5)
            elapsed += 5

    print('\n  ✅ Patient recovered successfully!')

except KeyboardInterrupt:
    print('\n  Monitor stopped.')
finally:
    if ser:
        ser.close()