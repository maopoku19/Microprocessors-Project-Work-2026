import serial 
try:
    s= serial.Serial('COM5', 9600, timeout=3)
    print('Connected! Waiting for data...')
    for i in range(10):
        line=s.readline()
        print(f'Raw: {repr(line)}')
    s.close()
except Exception as e:    
    print(f'Error: {e}')
