"""
AnomaVital Sentinel AI — PhysioNet Live Simulator
Replays real patient data row by row into the dashboard.
Simulates a real ward monitoring system with 10 patients.
"""

import csv
import os
import json
import time
import pandas as pd
from datetime import datetime

BASE_DIR    = r'C:\Users\HP\Documents\VitalSigns_Project'
DATA_FILE   = os.path.join(BASE_DIR, 'data', 'vitals_log.csv')
PATIENT_FILE= os.path.join(BASE_DIR, 'data', 'physionet_patients.csv')
PATIENT_JSON= os.path.join(BASE_DIR, 'data', 'current_patient.json')
CSV_HEADERS = ['timestamp','heart_rate','temperature','spo2','status','anomaly_detail']

BASELINE = {
    'heart_rate':  {'mean':72, 'std':10},
    'temperature': {'mean':36.8,'std':0.6},
    'spo2':        {'mean':98.5,'std':1.5},
}
WARN_THRESH     = 2.0
CRITICAL_THRESH = 3.5

def classify(hr, temp, spo2):
    status, details = 'NORMAL', []
    for name, value, key in [('heart_rate',hr,'heart_rate'),('temperature',temp,'temperature'),('spo2',spo2,'spo2')]:
        z = abs(float(value) - BASELINE[key]['mean']) / BASELINE[key]['std']
        if z >= CRITICAL_THRESH:
            details.append(f'{name}={value} CRITICAL')
            status = 'CRITICAL'
        elif z >= WARN_THRESH:
            details.append(f'{name}={value} WARNING')
            if status != 'CRITICAL': status = 'WARNING'
    return status, '; '.join(details)

def clear_csv():
    with open(DATA_FILE, 'w', newline='') as f:
        csv.DictWriter(f, fieldnames=CSV_HEADERS).writeheader()

def append_reading(hr, temp, spo2, status, detail, patient_id, condition):
    with open(DATA_FILE, 'a', newline='') as f:
        csv.DictWriter(f, fieldnames=CSV_HEADERS).writerow({
            'timestamp':      datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'heart_rate':     hr,
            'temperature':    temp,
            'spo2':           spo2,
            'status':         status,
            'anomaly_detail': f'[{patient_id}] {detail}' if detail else f'[{patient_id}] Normal'
        })

def save_current_patient(patient_id, condition, row_index, total_rows):
    with open(PATIENT_JSON, 'w') as f:
        json.dump({
            'patient_id': patient_id,
            'condition':  condition,
            'row_index':  row_index,
            'total_rows': total_rows,
            'updated_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }, f)

def show_menu(patients):
    print('\n' + '='*55)
    print('  AnomaVital Sentinel AI — Ward Monitor')
    print('='*55)
    print('  Available Patients:')
    for i, (pid, cond) in enumerate(patients):
        print(f'  [{i+1}] {pid} — {cond}')
    print('  [0] Exit')
    print('='*55)

def monitor_patient(df, patient_id, condition):
    patient_df = df[df['patient_id'] == patient_id].reset_index(drop=True)
    total = len(patient_df)
    clear_csv()

    print(f'\n  Monitoring {patient_id} — {condition}')
    print(f'  {total} readings available | Press Ctrl+C to return to menu\n')

    try:
        for i, row in patient_df.iterrows():
            hr   = float(row['heart_rate'])
            temp = float(row['temperature'])
            spo2 = float(row['spo2'])

            status, detail = classify(hr, temp, spo2)
            append_reading(hr, temp, spo2, status, detail, patient_id, condition)
            save_current_patient(patient_id, condition, i, total)

            icon = '🟢' if status=='NORMAL' else ('🟡' if status=='WARNING' else '🔴')
            print(f'  {icon} [{datetime.now().strftime("%H:%M:%S")}] '
                  f'HR={hr} | Temp={temp}°C | SpO2={spo2}% [{status}]')

            time.sleep(5)

        print(f'\n  ✅ Finished all readings for {patient_id}')
        time.sleep(5)

    except KeyboardInterrupt:
        print(f'\n  Returning to patient menu...')
        time.sleep(1)

def main():
    df = pd.read_csv(PATIENT_FILE)
    patients = [(pid, df[df['patient_id']==pid]['condition'].iloc[0])
                for pid in df['patient_id'].unique()]

    print('\n  Loading AnomaVital Sentinel AI Ward Monitor...')
    time.sleep(1)

    while True:
        show_menu(patients)
        try:
            choice = input('  Select patient number: ').strip()
            if choice == '0':
                print('  Goodbye!')
                break
            idx = int(choice) - 1
            if 0 <= idx < len(patients):
                pid, cond = patients[idx]
                monitor_patient(df, pid, cond)
            else:
                print('  Invalid choice. Try again.')
        except KeyboardInterrupt:
            print('\n  Goodbye!')
            break
        except ValueError:
            print('  Please enter a valid number.')

if __name__ == '__main__':
    main()