"""
Real-Time Vital Signs Generator
Continuously appends new readings to vitals_log.csv every 2 seconds.
Simulates a live patient sensor feed with realistic variation and occasional anomalies.
Run this in a SEPARATE terminal while the Flask dashboard is running.
"""

import csv
import os
import time
import random
import numpy as np
from datetime import datetime
import serial

# ── File path ──────────────────────────────────────────────────────────────────
DATA_FILE = r'C:\Users\HP\Documents\VitalSigns_Project\data\vitals_log.csv'
CSV_HEADERS = ['timestamp', 'heart_rate', 'temperature', 'spo2', 'status', 'anomaly_detail']

# ── Patient baseline (realistic adult at rest) ─────────────────────────────────
BASELINE = {
    'heart_rate':  {'mean': 72,   'std': 5},
    'temperature': {'mean': 36.8, 'std': 0.3},
    'spo2':        {'mean': 98.5, 'std': 0.8},
}

# Z-score thresholds
WARN_THRESH     = 2.0
CRITICAL_THRESH = 3.5

# Anomaly injection schedule (every N readings, inject an anomaly type)
ANOMALY_EVERY = 20   # inject an anomaly roughly every 20 readings
reading_count = 0

def generate_normal_reading():
    hr   = round(random.gauss(BASELINE['heart_rate']['mean'],   BASELINE['heart_rate']['std']),   1)
    temp = round(random.gauss(BASELINE['temperature']['mean'],  BASELINE['temperature']['std']),  1)
    spo2 = round(random.gauss(BASELINE['spo2']['mean'],         BASELINE['spo2']['std']),         1)
    # Clamp to physiological limits
    hr   = max(40, min(180, hr))
    temp = max(35.0, min(41.0, temp))
    spo2 = max(85.0, min(100.0, spo2))
    return hr, temp, spo2

def inject_anomaly():
    """Randomly pick one type of anomaly to inject."""
    anomaly_type = random.choice(['tachycardia', 'fever', 'hypoxia', 'bradycardia', 'hypothermia'])
    hr, temp, spo2 = generate_normal_reading()
    if anomaly_type == 'tachycardia':
        hr = round(random.uniform(120, 160), 1)
    elif anomaly_type == 'bradycardia':
        hr = round(random.uniform(35, 50), 1)
    elif anomaly_type == 'fever':
        temp = round(random.uniform(38.5, 40.2), 1)
    elif anomaly_type == 'hypothermia':
        temp = round(random.uniform(34.0, 35.5), 1)
    elif anomaly_type == 'hypoxia':
        spo2 = round(random.uniform(88.0, 93.0), 1)
    return hr, temp, spo2

def classify(hr, temp, spo2):
    details = []
    status  = 'NORMAL'

    for name, value, mean_key, std_key in [
        ('HR',   hr,   'heart_rate',  'heart_rate'),
        ('TEMP', temp, 'temperature', 'temperature'),
        ('SPO2', spo2, 'spo2',        'spo2'),
    ]:
        z = abs(value - BASELINE[mean_key]['mean']) / BASELINE[std_key]['std']
        if z >= CRITICAL_THRESH:
            details.append(f'{name}={value} (Z={z:.1f} CRITICAL)')
            status = 'CRITICAL'
        elif z >= WARN_THRESH:
            details.append(f'{name}={value} (Z={z:.1f} WARNING)')
            if status != 'CRITICAL':
                status = 'WARNING'

    return status, '; '.join(details) if details else ''

def ensure_csv():
    os.makedirs(os.path.dirname(DATA_FILE), exist_ok=True)
    if not os.path.exists(DATA_FILE):
        with open(DATA_FILE, 'w', newline='') as f:
            csv.DictWriter(f, fieldnames=CSV_HEADERS).writeheader()
        print(f"Created new CSV: {DATA_FILE}")

def append_reading(hr, temp, spo2, status, detail):
    with open(DATA_FILE, 'a', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=CSV_HEADERS)
        writer.writerow({
            'timestamp':     datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'heart_rate':    hr,
            'temperature':   temp,
            'spo2':          spo2,
            'status':        status,
            'anomaly_detail': detail
        })

def trim_csv(max_rows=200):
    """Keep the CSV from growing forever — keep only the last max_rows readings."""
    try:
        with open(DATA_FILE, 'r') as f:
            rows = list(csv.DictReader(f))
        if len(rows) > max_rows:
            with open(DATA_FILE, 'w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=CSV_HEADERS)
                writer.writeheader()
                writer.writerows(rows[-max_rows:])
    except Exception:
        pass

# ── Main loop ──────────────────────────────────────────────────────────────────
def main():
    global reading_count
    ensure_csv()

    print("=" * 55)
    print("  Real-Time Vital Signs Generator  🫀")
    print("  Generating new readings every 2 seconds...")
    print("  Press Ctrl+C to stop.")
    print("=" * 55)

    try:
        while True:
            reading_count += 1

            # Inject anomaly periodically
            if reading_count % ANOMALY_EVERY == 0:
                hr, temp, spo2 = inject_anomaly()
                print(f"  ⚠️  [#{reading_count}] ANOMALY injected")
            else:
                hr, temp, spo2 = generate_normal_reading()

            status, detail = classify(hr, temp, spo2)
            append_reading(hr, temp, spo2, status, detail)

            # Trim every 50 readings
            if reading_count % 50 == 0:
                trim_csv()

            icon = '🟢' if status == 'NORMAL' else ('🟡' if status == 'WARNING' else '🔴')
            print(f"  {icon} [{datetime.now().strftime('%H:%M:%S')}] "
                  f"HR={hr} bpm | Temp={temp}°C | SpO2={spo2}%  [{status}]")

            time.sleep(2)   # new reading every 2 seconds

    except KeyboardInterrupt:
        print("\n  Generator stopped. Goodbye!")

if __name__ == '__main__':
    main()
